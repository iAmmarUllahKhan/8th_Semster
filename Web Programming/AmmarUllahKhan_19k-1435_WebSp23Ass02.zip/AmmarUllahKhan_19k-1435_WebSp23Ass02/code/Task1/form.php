<html><head><title> Login</title></head>
<body>
<form method=" post" action="login. php">
<p>Username: <input type="text" name="username" /></p>
p>Password: <input type="password" name="password" /></p>
<p>cinput type="submit" value="Let me in" /></p>
</form></body></html>